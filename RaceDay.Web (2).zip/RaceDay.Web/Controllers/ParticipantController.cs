using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Services;
using RaceDay.Web.Models;

namespace RaceDay.Web.Controllers
{
    [Authorize]
    public class ParticipantController : Controller
    {
        private readonly IApiService _api;

        public ParticipantController(IApiService api)
        {
            _api = api;
        }

        public async Task<IActionResult> Dashboard()
        {
            try
            {
                var events = await _api.GetAsync<List<Event>>("api/events");

                // Safety check: If API returns null, give an empty list
                if (events == null) events = new List<Event>();

                return View(events);
            }
            catch (Exception ex)
            {
                ViewBag.Error = "Could not connect to API: " + ex.Message;
                return View(new List<Event>());
            }
        }

        [HttpGet]
        public IActionResult Apply(int raceId)
        {
            var model = new RaceEntry { RaceId = raceId };
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Apply(RaceEntry model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                await _api.PostAsync<RaceEntry>("api/raceentries", model);
                TempData["Success"] = "Application submitted successfully!";
                return RedirectToAction(nameof(Dashboard));
            }
            catch (Exception ex)
            {
                ViewBag.Error = "Failed to submit application: " + ex.Message;
                return View(model);
            }
        }
    }
}