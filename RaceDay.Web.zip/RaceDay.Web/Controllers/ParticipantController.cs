﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace RaceDay.Web.Controllers
{
    [Authorize] // Temporarily bypassed role restriction
    public class ParticipantController : Controller
    {
        public IActionResult Dashboard() => View();
    }
}